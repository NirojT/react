export interface ILoginData {
    username: string;
    password: string;
}
export interface ILoginDataError {
    username: string;
    password: string;
}