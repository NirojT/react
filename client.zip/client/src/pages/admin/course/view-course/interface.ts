export interface ICourseDetails {
    id: string;
    title: string;
    description: string;
    tagline: string;
    criteria: string
    duration: string;

}