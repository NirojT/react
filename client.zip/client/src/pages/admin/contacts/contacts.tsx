import React,{useEffect} from 'react'
import { adminLayoutStore } from '../layout/store';

const Contacts = () => {
    const setActiveUrl = adminLayoutStore((state: any) => state.setActiveUrl);
    useEffect(() => {
        setActiveUrl(window.location.pathname);
    }, [setActiveUrl]);
  return (
    <>Contacts</>
  )
}

export default Contacts