export interface ITenstimonialCards {
    image: string,
    words: string,
    name: string,
    designation: string
}
